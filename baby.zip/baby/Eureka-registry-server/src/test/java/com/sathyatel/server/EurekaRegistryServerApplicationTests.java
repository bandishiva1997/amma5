package com.sathyatel.server;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaRegistryServerApplicationTests {

	@Test
	 void contextLoads() {
	}

}
