package com.sathyatel.plandetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.plandetails.dto.PlanDTO;
import com.sathyatel.plandetails.service.IPlanService;

@RestController
public class PlanRestController {
	
	@Autowired
	IPlanService service;

	@GetMapping(value="/allPlans",produces="application/json")
	public List<PlanDTO> getAllPlans()
	{
		return service.getAllPlans();                 
	}

   @GetMapping(value="/{planId}",produces="application/json")
  public PlanDTO getSpecificPlan(@PathVariable String planId) {
	   
	return service.getSpecificPlan(planId);
	   
   }

}

