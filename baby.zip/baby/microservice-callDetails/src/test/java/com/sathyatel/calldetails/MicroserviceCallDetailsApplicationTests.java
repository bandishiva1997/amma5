package com.sathyatel.calldetails;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceCallDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
