
package com.sathyatel.friend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sathyatel.friend.entity.Friend;
import com.sathyatel.friend.service.IFriendService;
@RestController
public class FriendController {
	@Autowired
	IFriendService service;

	@PostMapping("/addFriend")
	public String addFriend(@RequestBody Friend friend) {
		
		return service.addFriendService(friend);
		
	}
	
	@GetMapping("/friends/{phoneNo}")
	public List<Long> getFrinds(@PathVariable Long phoneNo){
		
		return service.getFriendListService(phoneNo);
		
	}
	
}
