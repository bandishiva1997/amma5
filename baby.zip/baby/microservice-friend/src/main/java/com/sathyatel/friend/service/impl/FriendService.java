package com.sathyatel.friend.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.friend.entity.Friend;
import com.sathyatel.friend.repository.FriendRepository;
import com.sathyatel.friend.service.IFriendService;

@Service
public class FriendService implements IFriendService {

	@Autowired
	FriendRepository repository;

	@Override
	public String addFriendService(Friend friend) {
		Integer count=repository.verifyFriendNo(friend.getPhoneNo(),friend.getFriendNo());

		if(count==0) {
			repository.save(friend);
			return  "friend added successfully";
		}
		else {
			return "Sorry,Friend Number Already Exist!!!!!";
		}


	}


	@Override
	public List<Long> getFriendListService(Long phoneNo) {
		System.out.println(phoneNo);
		
		List<Friend> friendList=repository.findByPhoneNo(phoneNo);
		
		List<Long>  frindsNoList=new ArrayList<>();

		for(Friend friend:friendList) {
			Long friendNo=friend.getFriendNo();
			System.out.println("inside for loop");
			System.out.println(friendNo);
			frindsNoList.add(friendNo);
		}
		return frindsNoList;
	}


}
