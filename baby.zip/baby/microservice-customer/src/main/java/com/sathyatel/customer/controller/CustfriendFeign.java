/*
 * package com.sathyatel.customer.controller;
 * 
 * import java.util.List;
 * 
 * import org.springframework.cloud.openfeign.FeignClient; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.RequestMapping;
 * 
 * @FeignClient("FriendMs") public interface CustfriendFeign {
 * 
 * @RequestMapping("/FriendsDetails/friends/{phoneNo}") public List<Long>
 * getFriendsNumber(@PathVariable("phoneNo") Long phoneNo); }
 */