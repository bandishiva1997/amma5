package com.sathyatel.customer.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.command.AsyncResult;
import com.sathyatel.customer.dto.PlanDTO;

@Service
public class CustomerCircuitService {
	
	private static String PLAN_URL = "http://PLANMS/PlanApi/{planId}";
	
	private static String FRIEND_URL = "http://FRIENDMS/FriendsDetails/friends/{phoneNo}";
	
	/*
	 * @Autowired CustPlanFeign pfeign;
	 */
	
	/*
	 * @Autowired CustfriendFeign ffeign;
	 */
	
	@Autowired
	 RestTemplate restTemplate;
	
	
	
	//Synchronus
	/*
	 * public PlanDTO getPlanData(String planId) {
	 * 
	 * return restTemplate.getForObject(PLAN_URL,PlanDTO.class,planId); }
	 */
	
	//Asynchronus
	
	/*
	 * public Future<PlanDTO> getPlanData(String planId){
	 * 
	 * return new AsyncResult<PlanDTO>() {
	 * 
	 * public PlanDTO invoke() {
	 * 
	 * //return pfeign.getSpecificPlan(planId);
	 * 
	 * return restTemplate.getForObject(PLAN_URL,PlanDTO.class,planId); } }; }
	 */
	
	
	
	
	@HystrixCommand(fallbackMethod="getFriendsFallback")
	public List<Long> getFriends(Long phoneNo){
		
		//return ffeign.getFriendsNumber(phoneNo);
		
		return restTemplate.getForObject(FRIEND_URL,List.class,phoneNo);
	}

	//same return type and same parameter 
	
	public List<Long> getFriendsFallback(Long phoneNo){
		
		return new ArrayList<Long>();
	}
	
}
