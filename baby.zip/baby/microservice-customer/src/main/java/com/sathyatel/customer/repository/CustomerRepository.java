package com.sathyatel.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sathyatel.customer.dto.PlanDTO;
import com.sathyatel.customer.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

	@Query(value="select count(*) from customer_details where phone_no=? and password=?",nativeQuery=true)
	Integer customerCount(Long phoneNo,String password);
	
	/*
	 * @Query(value="update customer set plan_id=? where phone_no=?",nativeQuery=
	 * true) PlanDTO changePlanId(String planId,Long phoneNo);
	 */
}
