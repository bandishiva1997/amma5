package com.sathyatel.customer.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sathyatel.customer.dto.CustomerDTO;
import com.sathyatel.customer.dto.Login;
import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.repository.CustomerRepository;
import com.sathyatel.customer.service.ICustomerService;
@Service
public class CustomerService implements ICustomerService {


	@Autowired
	private CustomerRepository repo;

	@Override
	public boolean registerCustomer(Customer customer) {

		boolean flag=repo.existsById(customer.getPhoneNo());
		if(flag==true) {
			return false;
		}
		else {
			repo.save(customer);
			return true;
		}
	}	

	@Override
	public boolean loginCheck(Login login) {
		int flag=repo.customerCount(login.getPhoneNo(),login.getPassword());

		if(flag==1)
		{
			return true;	
		}
		else {
			return false;
		}
	}

	@Override
	public CustomerDTO getProfile(Long phoneNo) {
		Optional<Customer> opt=repo.findById(phoneNo);
		Customer customer=opt.get();
		CustomerDTO customerDto=new CustomerDTO();
		BeanUtils.copyProperties(customer, customerDto);
		return customerDto;
	}

}
