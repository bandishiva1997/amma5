/*
 * package com.sathyatel.customer.controller;
 * 
 * import org.springframework.cloud.openfeign.FeignClient; import
 * org.springframework.web.bind.annotation.PathVariable; import
 * org.springframework.web.bind.annotation.RequestMapping;
 * 
 * import com.sathyatel.customer.dto.PlanDTO;
 * 
 * @FeignClient("PlanMs") public interface CustPlanFeign {
 * 
 * @RequestMapping("/PlanApi/{planId}") public PlanDTO
 * getSpecificPlan(@PathVariable("planId") String planId);
 * 
 * 
 * 
 * 
 * }
 */