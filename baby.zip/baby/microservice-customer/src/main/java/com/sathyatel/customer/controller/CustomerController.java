package com.sathyatel.customer.controller;

import java.util.List;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.sathyatel.customer.dto.CustomerDTO;
import com.sathyatel.customer.dto.Login;
import com.sathyatel.customer.dto.PlanDTO;
import com.sathyatel.customer.entity.Customer;
import com.sathyatel.customer.service.ICustomerService;

@RestController
@RibbonClient(name="custribbon")
public class CustomerController {

	private static String PLAN_URL = "http://PLANMS/PlanApi/{planId}";
	
	//private static String FRIEND_URL = "http://FRIENDMS/FriendsDetails/friends/{phoneNo}";

	@Autowired
	ICustomerService service;

	
	 @Autowired
	 RestTemplate restTemplate;
		
	@Autowired
	CustomerCircuitService  circuit;

	/*
	 * private CustomerDTO customerDto;
	 * 
	 * @Autowired CustomerRepository repository;
	 */
	
	@PostMapping("/register")
	public String register(@RequestBody Customer customer) {

		boolean flag = service.registerCustomer(customer);

		if (flag == true) {
			return "customer is register";
		} else {
			return "Customer is already register";
		}
	}

	@PostMapping("/login")
	public boolean verifyLogin(@RequestBody Login login) {
		return service.loginCheck(login);
	}

	@GetMapping("/profile/{phoneNo}")
	public CustomerDTO viewProfile(@PathVariable Long phoneNo) {
		System.out.println("hiiiiiiiiiiii");
		CustomerDTO customerDto = service.getProfile(phoneNo);

		/* getforObject(String url,Class responseType,Object..var) */
		
		long x=System.currentTimeMillis();

		// Call PlanDetails-MicroService

         PlanDTO planDto=restTemplate.getForObject(PLAN_URL, PlanDTO.class,customerDto.getPlanId());
		
		 //syncronisation
		
	    // PlanDTO planDto=circuit.getPlanData(customerDto.getPlanId());
		
		
		//Asynchronus
		
        //Future<PlanDTO> future=circuit.getPlanData(customerDto.getPlanId());


		//for Ribbon concept bellow add this >>new RestTemplate()
		
		//PlanDTO planDto =new RestTemplate().getForObject(PLAN_URL, PlanDTO.class,customerDto.getPlanId());

		/*
		 * try {
		 * 
		 * customerDto.setPlanDto(future.get());
		 * 
		 * }catch (Exception e) { System.out.println(e); }
		 */
		
		customerDto.setPlanDto(planDto);

		/*
		 * return customerDto;
		 */
		// Call friendMicroservice
		
		//List friendsContactNumbers=restTemplate.getForObject(FRIEND_URL,List.class,customerDto.getPhoneNo());
		
		List<Long> friendsContactNumbers=circuit.getFriends(customerDto.getPhoneNo());
				
		long y=System.currentTimeMillis();
		System.out.println("Time Taken In Millis:"+(y-x));
		
		customerDto.setFriendsContactNumbers(friendsContactNumbers);
		;
		return customerDto;

	}
	/*
	 * 
	 * @PostMapping("/change") public PlanDTO changePlanId(@RequestBody
	 * ChangePlanchangePlan) { PlanDTO
	 * planDto=repository.changePlanId(changePlan.getPlanId(),changePlan.getPhoneNo( )); 
	 * return planDto; 
	 * }
	 * 
	 */
}
