package com.sathyatel.customer.service;

import com.sathyatel.customer.dto.CustomerDTO;
import com.sathyatel.customer.dto.Login;
import com.sathyatel.customer.entity.Customer;

public interface ICustomerService {
	
	boolean registerCustomer(Customer customer);
	
	boolean loginCheck(Login login);
	
	CustomerDTO getProfile(Long phoneNo);

}
